#!/bin/python3
#Name: Kassem Darawcha
#Date: 28/11/2022
import os 
while True:
        os.system("clear")
        pwd = os.getcwd()
        print(" \n Right Now you are in this path: "+  pwd)
        menu='''
        1. Create a shortcut in the home directory
        2. Remove a shortcut from the home directory
        3. Display Shortcut Report Summary        
        please write   quit    if you want to quit
        '''
        print(menu)
        user_selection =input( "please choose one of the above: ")
        if( user_selection == "quit" ):
            break
        if user_selection=="1":
                f1=input("Enter the name of the file: ")
                test_existence = os.path.exists(f1)
                if test_existence == True :
                    print(f1 + "the file you chose exists , now we will make a shortcut for it, please provide us the name you like: ")
                    sh1 = input()
                    s = os.path.join(os.path.expanduser("~"),sh1)
                    os.symlink(f1,  s)
                    print("Sorry we couldn't create the shortcut") 
                else:
                    print("Sorry we could not find the file.")

        elif user_selection=="2":
            sh2=input("Enter the name of the shortcut: ")
            sh2 = "/home/student/" + sh2
            test_existence2 = os.path.exists(sh2)
            if test_existence2 == True :
                readable_output2 = os.popen("find . -type l ").read()
                splitting =readable_output2.split("\n")
                for i in splitting:
                    if sh2 in i:
                        os.system("rm -r " + sh2)
                        print("Shortcut removed")

                        
            else:
                print("sorry we didn't find the shortcut, try again please ")

            os.system("rm -r  " + s)
            print("done , removed")


        elif user_selection=="3":
            dfgh=os.path.expanduser("~")            
            all_the_shortcuts = os.popen(f"find {dfgh} -type l").read()
            splitting3 =all_the_shortcuts.split("\n")
            numbers=len(splitting3)-1
            print("The number of the shortcuts in the home directory right now are: " +  str(numbers) + " and their paths are: ")
            for i in splitting3:
                    if i!="":
                        target= os.popen("readlink " + i).read() 
                        print("Shortcut:",i,'\t Target',target)
