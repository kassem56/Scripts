#!/usr/bin/python3
# Kassem Darawcha ||  25-09-2022
import os
import csv
from time import sleep
os.system('clear')
usernames = []
user_id = ''
name=''
office = ''
phone=''
base_directory = ''
user_group = ''
password = "password"
shelltype = ""
names=[]
all_groups = []
num=1
with open("linux_users.csv", 'r') as file:
  csvreader = csv.reader(file)
  next(csvreader)   # to skip the header
  for i in csvreader:
    all_groups.append(i[6])  # appending the groups to " all_groups " list , now we go to line ___ to check  if these groups exist or not 
  for i in all_groups:
    grp = os.popen("cat /etc/group").read()
    if(i in grp):
      print(i+ " group exists!")
    else:
      print(i+" group doesn't exist, we're creating one now...")
      sleep(2)
      os.popen("groupadd " + i)
      print("done!")
  for col in csvreader:
      try:
          user_id = col[0]
          lastname= col[1]
          firstname= col[2][0]
          username = firstname+lastname
          username = username.replace("'", "")
          if(username in names):
            username=username+'1'
          names.append(username)
          office = col[3]
          phone=col[4]
          base_directory = col[5]
          user_group = col[6]       
          #print("user" ,  num ,  " : ", user_id,username,office,phone,base_directory,user_group)
          if( bool(firstname) is False or bool(phone) is False or bool(base_directory) is False ):
            print("User account was not added due to missing information")
            num+=1
            continue            
          else:
            if base_directory == 'office':
                shelltype = 'csh'
            else:
                shelltype = 'bash'

            os.popen("sudo useradd "+ username) 
            sleep(2)            
            os.popen("sudo useradd -d /home/" + base_directory + " " + username)
            sleep(2)
            os.popen("useradd -G" + user_group + " " + username)
            sleep(2)
            os.popen("usermod --shell /bin/" + shelltype + " " + username )
            sleep(2)          
            os.popen("usermod -p " + password + " " +  username)
            sleep(2)
            os.popen("chage -d 0 " + username)
            sleep(2)                    
            num+=1  

      except IndexError:
              print("User account was not added due to missing information")
print("done adding the users! , have a good day (:") 




  






   
"""    try:
      for i in range(len(col)+1):
        print()





    except IndexError:
      print("User account was not added due to missing information")"""






































"""

          if(num in [2,4,6,8,10,12]):
               num+=1
               continue
              
          
          if(num==7):
            user_id = row[i]
            name = row[i+2][0] + row[i+1] + '1'
            office = row[i+3]
            phone = row[i+4]
            base_directory = row[i+5]
            user_group = row[i+6] 

          if(num==7):
            user_id = row[i]
            name = row[i+2][0] + row[i+1] + '1'
            office = row[i+3]
            phone = row[i+4]
            base_directory = row[i+5]
            user_group = row[i+6] 


          else:
            user_id = row[i]
            name = row[i+2][0] + row[i+1] 
            office = row[i+3]
            phone = row[i+4]
            base_directory = row[i+5]
            user_group = row[i+6] 

          print("user" , num , " : ", user_id,name,office,phone,base_directory,user_group)
          num+=1
      




 

"""
