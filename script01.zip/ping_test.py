#!/usr/bin/python3
# Kassem Darawcha ||  25-09-2022
import os
import subprocess


def ping(host): # function to ping a host
    code = os.popen('ping -c 4 ' + host).read()
    if  "0 received " not in  code:
        return True
    return False
 

def get_default_gateway():  # function to get default gateway
    res=subprocess.check_output(args=["ip", "route"]).decode("utf-8")    # get the default gateway
    for l in res.splitlines():
        if "default" in l:
            return l.split()[2]


def main():
    event = True
    while event:
        print   ("        Hello!\n        please choose number to complete the process\n            1 - Test connectivity to your gateway.\n            2 - Test for remote connectivity.\n            3 - Test for DNS resolution.\n            4 - Display gateway IP Address.\n            q - Exit")
        event = input("Enter option number : ")

        if( (event) == "q"):
            event = False

        elif(event=="2"):

            if ping("129.21.3.17") == True : # ping RIT's IP
                    print("RIT domain is ON")       # RIT is up
            else:
                    print("RIT domain is OFF")
            event =True

        elif(event=="3"):
            if ping("google.com"):  # ping Google DNS
                    print("Google domain is ON ")
            else:
                    print("Google Domain is OFF")
            event =True

        elif(event=="1"):


            if ping(get_default_gateway()):
                print("Default Gateway is ON") # default gateway is on
            if ping(get_default_gateway())==False:
                print("Default Gateway is OFF") # default gateway is on
            event =True

        elif(event=="4"):

            print("The default gateway is: " + get_default_gateway())   # display default gateway

            event =True


        else:
            print("Sorry, wrong input, could you try again?")
            event = True


main()       
        
            
