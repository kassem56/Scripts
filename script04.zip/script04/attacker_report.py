#!/usr/bin/env python3
#Name: Kassem Darawcha   Student ID: kkd5384     4/12/2022
import os,linecache,datetime , geoip
sentence = " "
all_ips = []
counter= 1
repeated_ips = {}
attackers=[]
countries=[]
counts=[]
os.system("clear")
print("Attacker Report")
print(datetime.date.today())
print("COUNT \t\t IP ADDRESS \t\t COUNTRY")
with open('syslog.log', 'r') as fp:
    # read all lines using readline()
    lines = fp.readlines()
    i=0
    for row in lines:
        # check if Faild present on a current line
        word = 'Failed'
        #print(row.find(word))
        # find() method returns -1 if the value is not found,
        if row.find(word) != -1:
            #print('string exists in file')
            z=lines.index(row)
            #print('line Number:', z)
            sentence = linecache.getline("syslog.log", z+1)
            x=str(sentence)
            c = sentence.rfind("Failed")
            ip_address = sentence[64:77]
            all_ips.append(ip_address)
            counts.append(c)
            i+=1
    for i in range(0,len(all_ips)):
        ip_1 = all_ips[i]
        counter=0
        for l in range(0,len(all_ips)):
            if(all_ips[l]==ip_1):
                counter+=1
                repeated_ips[ip_1]=counter
    for q,i in  repeated_ips.items():
        if (i>10):
           attackers.append(q)
    mm=0
    for i in attackers:
        country = geoip.geolite2.lookup(attackers[mm])
        countries.append(country.country)
        print(f"{counts[mm]} \t\t"+ i + "\t\t  "+countries[mm] )
        mm+=1




